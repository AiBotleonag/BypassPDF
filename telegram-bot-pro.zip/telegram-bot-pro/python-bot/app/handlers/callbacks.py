# app/handlers/callbacks.py
from telegram import Update
from telegram.ext import ContextTypes

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data
    if data == "help":
        await update.callback_query.message.reply_text("Use /start to begin.")
