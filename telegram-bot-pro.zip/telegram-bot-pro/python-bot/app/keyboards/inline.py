# app/keyboards/inline.py
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def main_menu():
    return InlineKeyboardMarkup([[InlineKeyboardButton("Help", callback_data="help")]])
