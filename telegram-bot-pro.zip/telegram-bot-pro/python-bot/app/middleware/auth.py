# app/middleware/auth.py
from telegram.ext import ChatMemberHandler

async def user_auth_middleware(update, context, next):
    return await next()
