# app/services/database.py
import aiosqlite
from app.config import Config

async def init_database():
    db = await aiosqlite.connect(Config.DATABASE_URL.replace("sqlite:///", ""))
    await db.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, user_id INTEGER)")
    await db.commit()
    await db.close()

async def get_or_create_user(user):
    db = await aiosqlite.connect(Config.DATABASE_URL.replace("sqlite:///", ""))
    cursor = await db.execute("SELECT * FROM users WHERE user_id=?", (user.id,))
    row = await cursor.fetchone()
    if not row:
        await db.execute("INSERT INTO users(user_id) VALUES(?)", (user.id,))
        await db.commit()
    await db.close()
    return user
