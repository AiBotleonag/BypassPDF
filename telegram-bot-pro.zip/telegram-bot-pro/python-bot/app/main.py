#!/usr/bin/env python3
import asyncio, logging, sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters
from app.config import Config
from app.handlers.commands import start, help_command
from app.handlers.messages import handle_text
from app.handlers.callbacks import button_callback
from app.middleware.auth import user_auth_middleware
from app.services.database import init_database

logging.basicConfig(level=Config().LOG_LEVEL)
logger = logging.getLogger(__name__)

class BotApp:
    def __init__(self):
        self.config = Config()
        self.app = None

    async def init(self):
        await init_database()
        self.app = Application.builder().token(self.config.BOT_TOKEN).build()
        self.app.add_handler(CommandHandler("start", start))
        self.app.add_handler(CommandHandler("help", help_command))
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
        self.app.add_handler(CallbackQueryHandler(button_callback))
        self.app.add_middleware(user_auth_middleware)

    async def run(self):
        await self.init()
        if self.config.WEBHOOK_URL:
            await self.app.bot.set_webhook(url=self.config.WEBHOOK_URL)
            logger.info("Webhook set")
            await self.app.start_webhook(listen="0.0.0.0", port=self.config.PORT, path="/")
        else:
            await self.app.run_polling()

if __name__ == "__main__":
    asyncio.run(BotApp().run())
