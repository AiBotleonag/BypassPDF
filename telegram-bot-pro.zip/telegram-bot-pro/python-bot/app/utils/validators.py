# app/utils/validators.py
def is_valid_text(text):
    return isinstance(text, str) and len(text)>0
