# app/utils/helpers.py
def format_size(bytes):
    for unit in ['B','KB','MB']: 
        if bytes<1024: return f"{bytes}{unit}"
        bytes//=1024
