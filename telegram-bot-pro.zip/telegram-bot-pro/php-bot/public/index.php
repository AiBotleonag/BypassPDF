<?php
require __DIR__ . '/../vendor/autoload.php';
use Src\Config\BotConfig;
use Src\Handlers\CommandHandler;
$input = json_decode(file_get_contents('php://input'), true);
if(isset($input['message']['text'])){
    if(str_starts_with($input['message']['text'],'/start')){
        CommandHandler::start($input['message']);
    }
}
echo json_encode(['ok'=>true]);
