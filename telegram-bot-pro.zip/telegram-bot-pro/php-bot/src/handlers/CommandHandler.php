<?php
namespace Src\Handlers;
use Src\Config\BotConfig;
class CommandHandler {
    public static function start($msg){
        $chat = $msg['chat']['id'];
        file_get_contents("https://api.telegram.org/bot".BotConfig::token()."/sendMessage?chat_id=$chat&text=Hello");
    }
}
