<?php
namespace Src\Keyboards;
class InlineKeyboard { public static function main(){ return [['text'=>'Help','callback_data'=>'help']]; } }
