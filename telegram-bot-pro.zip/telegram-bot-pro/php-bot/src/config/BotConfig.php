<?php
namespace Src\Config;
class BotConfig {
    public static function token(){ return getenv('BOT_TOKEN'); }
}
