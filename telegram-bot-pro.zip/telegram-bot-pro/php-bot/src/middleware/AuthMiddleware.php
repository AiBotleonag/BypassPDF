<?php
namespace Src\Middleware;
class AuthMiddleware { public static function check($msg){ return true; } }
