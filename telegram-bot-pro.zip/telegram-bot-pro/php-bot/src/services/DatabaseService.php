<?php
namespace Src\Services;
class DatabaseService {
    private static $file = __DIR__.'/../../storage/users.json';
    public static function getUsers(){
        return json_decode(file_get_contents(self::$file),true);
    }
    public static function addUser($id){
        $u=self::getUsers(); $u[]=$id;
        file_put_contents(self::$file,json_encode($u));
    }
}
